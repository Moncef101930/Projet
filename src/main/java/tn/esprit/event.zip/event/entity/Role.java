package tn.esprit.event.entity;

public enum Role {
    ADMIN,USER
}
